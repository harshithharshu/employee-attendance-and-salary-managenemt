<?php
	if($_SESSION['UserID']==NULL){
		header('Location: ulogin.php');
	}
?>