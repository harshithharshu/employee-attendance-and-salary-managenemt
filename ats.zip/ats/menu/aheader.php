<div id="header">
    <h1 id="logo-text"><a href="#">PES UNIVERSITY</a></h1>
    <p id="slogan">Attendance And SALARY Management System</p>
    <div id="header-links">
       <p>
            

        </p> 
    </div>
</div>