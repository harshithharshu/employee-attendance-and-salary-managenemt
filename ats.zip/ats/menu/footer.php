<div id="footer">
    <p>
        &copy; 2016 <strong>PES</strong> |
        <a href="#" title="Website Templates">website templates</a> by <a href="#">CSE</a> |
        Valid <a href="#">XHTML</a> | 
        <a href="#">CSS</a>   		
    </p>
</div>
<?php $_SESSION['Msg']=''; ?>