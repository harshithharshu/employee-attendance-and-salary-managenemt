
<div id="header">
    <table width="500px" class="tbl">
<h1 id="logo-text"><a href="#">PES UNIVERSITY</a></h1>
</table>
    <p id="slogan">Attendance And SALARY Management System</p>
    <div id="header-links">
       <p>
            <li><a href="aindex.php">Home</a>  </li>
        <li id="menuEmployeeList" ><a href="process/processLogout.php">Logout</a></li>

<P align="center">
<h4>
<?php echo "WELCOME TO Administrator";?>		
  </h4></p>


        </p> 
    </div>
</div>