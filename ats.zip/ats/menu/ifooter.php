<div id="footer">
    <p style="color:#ADFF2F;font-size:20px">
       
<?php
$handle = file_get_contents("counter.txt");
$handle=explode("=",$handle);
$handle[1]=$handle[1]+1;

$file=fopen("counter.txt","w+");
fwrite($file,"count=".$handle[1]);

fclose($file);
print "Total number  visitors of Web Page:<strong>".$handle[1]."</strong>";

?>
	
    </p>
</div>
<?php $_SESSION['Msg']=''; ?>