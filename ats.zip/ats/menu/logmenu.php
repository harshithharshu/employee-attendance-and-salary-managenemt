<div  id="menu">
    <ul>
<li id="menuEmployee" ><a href="index.php">HOME</a></li>
        <li id="menuAttandance" ><a href="ulogin.php">Employee Mode</a></li>
        <li id="menuEmployee" ><a href="login.php">Admin Mode</a></li>
              <li id="menuEmployee" ><a href="adduser.php">REGISTERATION FORM</a></li>

    </ul>
</div>	