<div id="header">
    <h1 id="logo-text"><a href="#">PES UNIVERSITY</a></h1>
    <p id="slogan">Attendance And SALARY Management System</p>
    <div id="header-links">
   <li><a href="uindex.php">Home</a>  </li>
        <li id="menuEmployeeList" ><a href="process/processLogout.php">Logout</a></li>
<P align="center">
<h4>
<?php echo "WELCOME TO:<big>".$_SESSION['Mg']."</big>";?>		
  </h4></p>


    </div>
</div>