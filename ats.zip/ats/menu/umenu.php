<div  id="menu">
    <ul>
       <li id="menuHome"><a href="uindex.php">Home</a></li>
        
        
       
        <li id="menuEmployeeReport" ><a href="uEmployeeReport.php">Emp Report</a></li>
 <li id="menuEmployeeReport" ><a href="emp.php">Employee details</a></li>
 
    </ul>
</div>	