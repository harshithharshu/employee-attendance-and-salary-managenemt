<?php 
@require_once 'config/config.php';

@require_once 'class/dbclass.php';



?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
    <head>
        <?php require_once 'config/commonJS.php'; ?>
        

      
        

        


        <script>
            window.onload = menuSelect('menuHome');
        </script>
    </head>
    <body  >
        <!-- wrap starts here -->
        <div id="wrap">

            <!--header -->
            <?php @require_once 'menu/aheader.php'; ?>

            <!-- navigation -->	
            <?php @require_once 'menu/logmenu.php'; ?>

            <!-- content-wrap starts here -->
    <div id="content-wrap">
                
	
<h1 align="center"><b>ATTENDANCE AND SALARY MANAGEMENT SYSTEM</b></h1>
			

                    <form id="formSubmit" method="post" >
                        


<p align="center"> <img src="attendence.jpg" width=300 height=300 usemap="#Map">
<map name="Map" id="Map"><area shape="poly" coords="160,185" href="#" alt="" /></map></p>
<p align="justify"><font face="Courier New, Courier, monospace"><strong><font color="#3300FF" size="4">MY PROJECT <font color="#FF0000">�EMPLOYEE ATTENDANCE & SALARY MANAGEMENT SYSTEM�</font> FOCUS ON DAILY ATTENDANCE OF STAFF IN ANY COLLAGE,INSTITUTION & ETC.,.IT FACILITATES TO SEE THE PARTICULAR STAFF MEMBERS ATTENDANCE REPORT & WE CAN SEE THE COMPARISION OF EMPLOYEE�S WITH OTHERS.EMPLOYEE CAN REQUEST FOR A JOBIN USER BY REGISTERATION FORM IN USER MODE AND ADMINISTRATOR CAN ACCEPT THE JOB BY FIXING SALARY OR REJECTING IT BY DELETING APPLICATION.IT IS FULLY AUTHENTICATED APPLICATION HAVING SECURE DATABASE ACCESS.THE ADMINHAS FULL RIGHTS TO MODIFY THE DATABASE BUT EMPLOYEE MODE HE CAN ONLY VIEW THE DATABASE DATA,BUT HE CANNOT CHANGE ANYTHING.HE CAN SEE COMPARISION OF ATTENDANCE  WITH  OTHER EMPLOYEES.IN THIS PROJECT WE ALSO HAVE SALARY SYSTEMINEASY WAY.HERE,FIRST ADMINISTRATOR VIEWS THE LIST OF EMPLOYEES REGISTERED AND FIXES THE SALARY TO EMPLOYEE & HE CAN ADD NEXT INCREMENT AMOUNT & WHEN SHOULD IT BE INCREMENTED.HE CAN ALSO INCREASE AND REDUCE THE SALARY OF EMPLOYEE BY UPDATING THE SALARY DETAILS WHEN THE INCREMENT DATE COMES ,IT NOTIFIES US UPDATES AVAILABLE WE CAN UPADATE THE STATUS.HERE ADMINSTRATOR CAN VIEW FULL DETAILS OF EMPLOYEE & HE CAN SORT IT BY ANY WAY HE WANTS.IT HAS THE SPEED SEACHING TOOLFOR SEARCHING THE EMPLOYEE DETAILS.HERE BOTH EMPLOYEE AND ADMINSTRATOR CAN SEE  THE ATTENDANCE & SALARY REPORT & PRINT IT.THE ADMINISTRATOR PUT THE ATTENDANCE TO THE EMPLOYEE .IT IS VERY USER INTERACTIVE FOR MAINTAINING THE ATTENDANCE AND SALARY REPORT IN THIS WEB APPLICATION.IT IS FULLY SECURED WEB APPLICATION.WE CAN USE IT ANY WHERE WE NEED IT.IT IS LESS EXPENSIVE WHEN COMPARE TO BIO-METRIC SYSTEM.SO IT CAN BE USED BY MEDIUM AND SMALL RANGE COLLAGES AND INSTITUTES,ETC.,.IT REDUCES EXPENDITURE OF MAINTAINING ATTENDANCE AND SALARY MANAGEMENT .THE PROJECT IS MAINLY USER INTERACTIVE.</font></strong></font></p>
                    </form>
  
               
           
            <!-- content-wrap ends here -->
            </div>
            <!--footer starts here-->
            <?php @require_once 'menu/ifooter.php'; ?>
            <!-- wrap ends here -->
        </div>



    </body>
</html>
