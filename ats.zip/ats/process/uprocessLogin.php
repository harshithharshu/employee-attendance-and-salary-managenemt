<?php
require_once '../config/config.php';
require_once '../class/dbclass.php';
require_once "../class/eUser.php";

$user = new User();

if($_POST['type']=='login'){
	if($user->login()){

$_SESSION['Mg'] =  $_POST['UserName'];
		header('Location: ../uindex.php');


}else{
		$_SESSION['Msg'] = "Invalid UserName Or Password";
		header('Location: ../ulogin.php');
	}
}
else if($_POST['type']=='register'){
	
}else{
	header('Location : ../ulogin.php');
}
?>
